int add;
int sub;
int  main(){
    int a=5;
    int b=3;
    add=a+b;
    sub=a-b;
    return 0;
}
