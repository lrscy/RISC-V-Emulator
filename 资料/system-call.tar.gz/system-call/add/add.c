#include <stdio.h>
int add;
int sub;
int  main(){
    int a=5;
    int b=3;
    add=a+b;
    sub=a-b;
    printf("add=%d,sub=%d\n",add,sub);
    return 0;
}
