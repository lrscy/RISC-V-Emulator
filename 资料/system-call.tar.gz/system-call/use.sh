#!/bin/bash

export PATH=$PATH:/opt/riscv/bin

riscv64-unknown-elf-gcc -o add/add.out add/add.c
riscv64-unknown-elf-readelf -a add/add.out >add/add-elf
riscv64-unknown-elf-objdump -D add/add.out >add/add-dump
xxd add/add.out >add/add-bin

riscv64-unknown-elf-gcc -o HanNo/HanNo.out HanNo/HanNo.c
riscv64-unknown-elf-readelf -a HanNo/HanNo.out >HanNo/HanNo-elf
riscv64-unknown-elf-objdump -D HanNo/HanNo.out >HanNo/HanNo-dump
xxd HanNo/HanNo.out >HanNo/HanNo-bin
